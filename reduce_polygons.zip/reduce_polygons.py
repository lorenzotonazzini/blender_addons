bl_info = {
    "name": "Reduce_poly_count",
    "author": "Lorenzo Tonazzini",
    "version": (1, 0),
    "blender": (3, 1, 2),
    "location": "View3D > Custom",
    "description": "Reduce polygons count",
    "warning": "",
    "doc_url": "",
    "category": "Apply",
}


import bpy
from bpy.types import Operator
from bpy.props import *
from bpy_extras.object_utils import AddObjectHelper, object_data_add


class ReducePolyCount(Operator, AddObjectHelper):
    """Reduce numbers of polygons"""
    bl_options = {'REGISTER', 'UNDO'}
    bl_idname = 'object.reduce_poly_count'
    bl_label = 'Reduce polygons count'
    
    #create properties
    ratio: FloatProperty (
        name = 'Ratio',
        description = 'Ratio to apply',
        default = 0.8,
        min = 0,
        max = 1.0
    )
    
    polyCount: IntProperty (
        name = 'Minimum number of poly',
        description = 'Minimum number of polygons to apply modifiers',
        default = 1000,
        min = 0,
    )

    def execute(self, context):
        for ob in bpy.data.objects:
            if ob.type == 'MESH' and len(ob.data.polygons) > self.polyCount :
                modDec = ob.modifiers.new("Decimate", type = "DECIMATE")
                modDec.ratio = self.ratio
                #apply context
                bpy.context.view_layer.objects.active = ob
                try:
                    bpy.ops.object.convert(target='MESH')
                except:
                    pass

        return {'FINISHED'}


# Registration

def ReducePolyCount_button(self, context):
    self.layout.operator(
        ReducePolyCount.bl_idname,
        text="Reduce polygons",
        icon='PLUGIN')


def register():
    bpy.utils.register_class(ReducePolyCount)
    bpy.types.VIEW3D_MT_mesh_add.append(ReducePolyCount_button)


def unregister():
    bpy.utils.unregister_class(ReducePolyCount)
    bpy.types.VIEW3D_MT_mesh_add.remove(ReducePolyCount_button)


if __name__ == "__main__":
    register()
