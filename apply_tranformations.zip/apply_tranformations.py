bl_info = {
    "name": "Reset Tranforms",
    "author": "Lorenzo Tonazzini",
    "version": (1, 0),
    "blender": (3, 1, 2),
    "location": "View3D > Custom",
    "description": "Reset Tranforms",
    "warning": "",
    "doc_url": "",
    "category": "Apply",
}


import bpy
from bpy.types import Operator
from bpy_extras.object_utils import AddObjectHelper, object_data_add


class ResetTransforms(Operator, AddObjectHelper):
    """Reset Transforms"""
    bl_options = {'REGISTER', 'UNDO'}
    bl_idname = 'object.reset_transforms'
    bl_label = 'Reset Transforms'
    

    def execute(self, context):
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        return {'FINISHED'}


# Registration

def ResetTransforms_button(self, context):
    self.layout.operator(
        ResetTransforms.bl_idname,
        text="Reset Transforms4",
        icon='PLUGIN')


def register():
    bpy.utils.register_class(ResetTransforms)
    bpy.types.VIEW3D_MT_mesh_add.append(ResetTransforms_button)


def unregister():
    #bpy.utils.unregister_class(ResetTransforms)
    bpy.types.VIEW3D_MT_mesh_add.remove(ResetTransforms_button)


if __name__ == "__main__":
    register()
